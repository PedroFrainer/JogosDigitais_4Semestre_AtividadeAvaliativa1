public static class PhysicsConstants
{
    public static float gravity = 9.81f;
}