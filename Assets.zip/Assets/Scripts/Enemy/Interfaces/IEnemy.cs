public interface IEnemy
{
    void TakeDamage(int damage);
}