public interface ICharacter
{
    void TakeDamage(int damage);
}