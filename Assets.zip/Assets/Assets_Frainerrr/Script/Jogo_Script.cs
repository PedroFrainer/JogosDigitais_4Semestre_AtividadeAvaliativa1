using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class Jogo_Script : MonoBehaviour
{
    public GameObject Jogo;
        public GameObject Jogador;
            public int Jogador_Vida;
                public int Jogador_Vida_Contador;
                public int Jogador_Vida_Display;
                public bool Jogador_Vida_Danificado;
                public bool Jogador_Vida_Recebida;
            public int Jogador_Municao;
                public bool Jogador_Municao_Recarregar_Bool;
        public GameObject Entidades;
            public GameObject Entidades_Inimigo;
        public GameObject Menu;
            public GameObject Menu_Inicial;
                public bool Menu_Inicial_Bool;
                public GameObject Menu_Inicial_Botao_Jogar;
                    public TextMeshProUGUI Menu_Inicial_Botao_Jogar_Texto;
                public GameObject Menu_Inicial_Botao_Sair;
                        public TextMeshProUGUI Menu_Inicial_Botao_Sair_Texto;
            public GameObject Menu_Ingame;
                public TextMeshProUGUI Menu_Ingame_Botao_Vida_Texto;
                public TextMeshProUGUI Menu_Ingame_Botao_Municao_Texto;
                public GameObject Menu_Ingame_Pausado;
                    public GameObject Menu_Ingame_Pausado_Botao_Voltar;
                        public TextMeshProUGUI Menu_Ingame_Pausado_Botao_Voltar_Texto;
                    public GameObject Menu_Ingame_Pausado_Botao_Sair;
                        public TextMeshProUGUI Menu_Ingame_Pausado_Botao_Sair_Texto;
                public GameObject Menu_Ingame_Pipboy;
                    public GameObject Menu_Ingame_Pipboy_Index;
                    public GameObject Menu_Ingame_Pipboy_Armas;
                    public GameObject Menu_Ingame_Pipboy_Arvore;
    void Start()
    {
    // Menu
        // Menu_Inicial
        Menu_Inicial_Bool=true;
        // Menu_Ingame
        Menu_Ingame.SetActive(false);
            // Menu_Ingame_Pausado
    // Jogador
        // Jogador_Vida
        Jogador_Vida=21;
        Jogador_Vida_Funcao();
        // Jogador_Municao
        Jogador_Municao=99;
    }
// Update
    void Update()
    {
    // Update_Menu
        // Update_Menu_Inicial
        if (Menu_Inicial_Bool==false)
        {
            if (Input.GetKey("escape"))
            {
            Menu_Ingame_Pausado.SetActive(true);
            }
    // Update_Jogador
        // Update_Jogador_Municao
        // Update_Jogador_Vida
        //Menu_Ingame_Botao_Vida_Texto.text=Jogador_Vida.ToString();
        }
    }
// FixedUpdate
    void FixedUpdate()
    {
    // FixedUpdate_Jogador
        // FixedUpdate_Jogador_Municao
        Menu_Ingame_Botao_Municao_Texto.text=Jogador_Municao.ToString();
        if (Menu_Inicial_Bool==false)
        {
        if (Jogador_Municao<=9)
        {
            Menu_Ingame_Botao_Municao_Texto.text="0"+Jogador_Municao.ToString();
        }
        if (Jogador_Municao>=1&&Jogador_Municao_Recarregar_Bool==false)
        {
            if (Input.GetKey((KeyCode.Mouse0)))
            {
            Jogador_Municao=Jogador_Municao-1;
            }

        }   
            // FixedUpdate_Jogador_Municao_Recarregar
            if (Jogador_Municao<=98)
            {
                if (Input.GetKey(KeyCode.R))
                {
                Jogador_Municao_Recarregar_Bool=true;
                Jogador_Municao_Recarregar_Funcao();
                }
            }
        }
    }
// Funcoes
    // Funcoes_Menu
        // Funcoes_Menu_Inicial
            public void Menu_Inicial_Botao_Jogar_Funcao()
            {
                Menu_Inicial_Bool=false;
                Menu_Inicial.SetActive(false);
                Menu_Ingame.SetActive(true);
                Menu_Ingame_Pausado.SetActive(false);
            }
            public void Menu_Inicial_Botao_Sair_Funcao()
            {
                Application.Quit();
            }
        // Funcoes_Menu_Ingame_Pausado
            public void Menu_Ingame_Pausado_Botao_Voltar_Funcao()
            {
                Menu_Ingame_Pausado.SetActive(false);
            }
            public void Menu_Ingame_Pausado_Botao_Sair_Funcao()
            {
                Application.Quit();
            }
    // Funcoes_Jogador
        // Funcoes_Jogador_Vida
        public void Jogador_Vida_Funcao ()
        {
            for (int Jogador_Vida_Contador=0;Jogador_Vida_Contador<Jogador_Vida;Jogador_Vida_Contador++)
            {
                Menu_Ingame_Botao_Vida_Texto.text=Menu_Ingame_Botao_Vida_Texto.text+"l";
            }
        }
            // Funcoes_Jogador_Vida_Danificado
            public void Jogador_Vida_Danificado_Funcao()
            {
                if (Jogador_Vida_Danificado==true)
                {
                Jogador_Vida=Jogador_Vida-1;
                Jogador_Vida_Funcao();
                Jogador_Vida_Danificado=false;
                }
            }
            public void Jogador_Vida_Recebida_Funcao()
            {
                if (Jogador_Vida_Recebida==true)
                {
                Jogador_Vida=Jogador_Vida+1;   
                Jogador_Vida_Funcao();
                Jogador_Vida_Recebida=false;
                }
            }
        // Funcoes_Jogador_Municao
            // Funcoes_Jogador_Recarregar
            public void Jogador_Municao_Recarregar_Funcao()
            {
            Jogador_Municao=Jogador_Municao+1;
            Jogador_Municao_Recarregar_Bool=false;
            }
}
